/* eslint-disable */
// Tela 3 — Relatório (stepper, 3 de 7 etapas mostradas)

function StepperHeader({ current, total = 7, title }) {
  return (
    <div style={{
      background: '#fff',
      paddingTop: 44,
      paddingBottom: 14,
      paddingLeft: 16, paddingRight: 16,
      borderBottom: `1px solid ${Nut.n100}`,
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        minHeight: 36, marginBottom: 12,
      }}>
        <button style={{
          background: Nut.navy50, border: 0, cursor: 'pointer',
          width: 34, height: 34, borderRadius: '50%',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: Nut.navy, flexShrink: 0,
        }}>
          <Icon name="close" size={20} weight={600} />
        </button>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{
            fontFamily: 'Poppins, sans-serif',
            fontSize: 14, fontWeight: 700, color: Nut.navy,
            letterSpacing: '-0.01em',
          }}>Relatório de visita</div>
          <div style={{
            fontSize: 11, color: Nut.n500, marginTop: 1,
            fontFamily: 'JetBrains Mono, monospace',
          }}>
            Etapa {current} de {total}
          </div>
        </div>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 5,
          padding: '5px 9px', borderRadius: 9999,
          background: Nut.success50, color: '#166534',
          fontSize: 10.5, fontWeight: 600,
          fontFamily: 'Inter, sans-serif',
          flexShrink: 0,
        }}>
          <Icon name="cloud_done" size={13} color={Nut.success} fill={1} />
          Salvo há 8s
        </div>
      </div>

      {/* progress bar — 7 segments */}
      <div style={{ display: 'flex', gap: 3 }}>
        {Array.from({ length: total }).map((_, i) => (
          <div key={i} style={{
            flex: 1, height: 4, borderRadius: 2,
            background: i < current ? Nut.lime : Nut.n200,
          }} />
        ))}
      </div>
    </div>
  );
}

function StepFooter({ nextLabel = 'Próximo' }) {
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: '#fff',
      borderTop: `1px solid ${Nut.n100}`,
      padding: '12px 16px 26px',
      display: 'flex', gap: 10,
      zIndex: 10,
    }}>
      <Btn variant="secondary" size="lg" style={{ flex: 0.55, padding: '0 18px' }}>
        Voltar
      </Btn>
      <Btn variant="primary" size="lg" iconRight="arrow_forward"
        style={{ flex: 1 }}>
        {nextLabel}
      </Btn>
    </div>
  );
}

function SectionLabel({ n, title, subtitle }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6,
      }}>
        <span style={{
          width: 28, height: 28, borderRadius: '50%',
          background: Nut.lime, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Poppins, sans-serif', fontSize: 13, fontWeight: 700,
          flexShrink: 0,
        }}>{n}</span>
        <h2 style={{
          margin: 0,
          fontFamily: 'Poppins, sans-serif',
          fontSize: 20, fontWeight: 700, color: Nut.navy,
          letterSpacing: '-0.02em', lineHeight: 1.2,
        }}>{title}</h2>
      </div>
      {subtitle && (
        <div style={{
          fontSize: 13, color: Nut.n600, marginLeft: 38,
          lineHeight: 1.4,
        }}>{subtitle}</div>
      )}
    </div>
  );
}

// ─── Etapa 2 — Horário declarado ─────────────────────────────
function Step2Schedule() {
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: Nut.n50, position: 'relative' }}>
      <StepperHeader current={2} total={7} />
      <div style={{ flex: 1, overflow: 'auto', padding: '20px 16px 120px' }}>
        <SectionLabel n={2} title="Horário declarado"
          subtitle="Entre 13:02 e 16:02 (±1h30 do check-in)" />

        {/* Check-in reference */}
        <div style={{
          background: Nut.navy50, borderRadius: 10,
          padding: '10px 14px',
          display: 'flex', alignItems: 'center', gap: 10,
          marginBottom: 20,
          fontSize: 12,
        }}>
          <Icon name="location_on" size={16} color={Nut.navy} weight={600} fill={1} />
          <span style={{ color: Nut.n600 }}>Check-in:</span>
          <span style={{
            fontFamily: 'JetBrains Mono, monospace',
            fontWeight: 700, color: Nut.navy, letterSpacing: '-0.01em',
          }}>14:32 · São Luiz Morumbi</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
          {[
            { lbl: 'Início',   val: '14', mm: '15' },
            { lbl: 'Término',  val: '15', mm: '45' },
          ].map((p, i) => (
            <div key={i} style={{
              background: '#fff', borderRadius: 14,
              padding: '14px 14px 12px',
              border: `1.5px solid ${i === 0 ? Nut.lime : Nut.n200}`,
              boxShadow: i === 0 ? '0 0 0 3px rgba(139,198,63,0.2), 0 2px 8px rgba(10,31,92,0.05)'
                                  : '0 2px 8px rgba(10,31,92,0.05)',
            }}>
              <div style={{
                fontSize: 10.5, fontWeight: 700, letterSpacing: '0.08em',
                textTransform: 'uppercase', color: Nut.n500,
                marginBottom: 8,
              }}>{p.lbl}</div>
              <div style={{
                display: 'flex', alignItems: 'baseline', gap: 4,
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: 40, fontWeight: 700, color: Nut.navy,
                letterSpacing: '-0.04em', lineHeight: 1,
              }}>
                <span>{p.val}</span>
                <span style={{ color: Nut.n300 }}>:</span>
                <span>{p.mm}</span>
              </div>
              <div style={{
                marginTop: 10,
                display: 'flex', justifyContent: 'space-between',
                gap: 6,
              }}>
                <button style={{
                  flex: 1, height: 34, borderRadius: 9,
                  background: Nut.navy50, color: Nut.navy, border: 0,
                  fontSize: 12, fontWeight: 600, cursor: 'pointer',
                  fontFamily: 'Inter, sans-serif',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
                }}>
                  <Icon name="remove" size={14} weight={700} /> 15min
                </button>
                <button style={{
                  flex: 1, height: 34, borderRadius: 9,
                  background: Nut.navy50, color: Nut.navy, border: 0,
                  fontSize: 12, fontWeight: 600, cursor: 'pointer',
                  fontFamily: 'Inter, sans-serif',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
                }}>
                  <Icon name="add" size={14} weight={700} /> 15min
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Time range validation */}
        <div style={{
          background: '#fff',
          border: `1px solid ${Nut.success}40`,
          borderRadius: 12,
          padding: '12px 14px',
          display: 'flex', alignItems: 'flex-start', gap: 10,
        }}>
          <Icon name="check_circle" size={18} color={Nut.success} weight={600} fill={1} />
          <div>
            <div style={{
              fontSize: 13, fontWeight: 600, color: '#15803d',
            }}>Duração: 1h 30min</div>
            <div style={{
              fontSize: 11.5, color: Nut.n600, marginTop: 1,
            }}>Dentro da tolerância esperada.</div>
          </div>
        </div>
      </div>
      <StepFooter />
    </div>
  );
}

// ─── Etapa 4 — Profissionais ─────────────────────────────────
function Step4Professionals() {
  const chips = [
    { name: 'Dra. Ana Paula',   role: 'Nutricionista' },
    { name: 'Dr. João Ferreira', role: 'Farmacêutico' },
  ];
  const suggestions = [
    { name: 'Dra. Marina Souza', role: 'Nutricionista' },
    { name: 'Dr. Rafael Lima',   role: 'Médico' },
  ];
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: Nut.n50, position: 'relative' }}>
      <StepperHeader current={4} total={7} />
      <div style={{ flex: 1, overflow: 'auto', padding: '20px 16px 120px' }}>
        <SectionLabel n={4} title="Profissionais conversados"
          subtitle="Quem esteve com você na visita." />

        {/* Chip field */}
        <div style={{
          background: '#fff',
          borderRadius: 14,
          padding: 12,
          border: `1.5px solid ${Nut.n200}`,
          marginBottom: 14,
          display: 'flex', flexWrap: 'wrap', gap: 8,
          boxShadow: '0 2px 8px rgba(10,31,92,0.04)',
        }}>
          {chips.map(c => (
            <span key={c.name} style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              padding: '6px 6px 6px 10px',
              borderRadius: 9999,
              background: Nut.lime50,
              border: `1px solid ${Nut.lime}66`,
              fontSize: 12.5, fontWeight: 600, color: Nut.navy,
              fontFamily: 'Inter, sans-serif',
              maxWidth: '100%',
            }}>
              <Avatar initials={c.name.split(' ').slice(-2).map(s => s[0]).join('')} size={22} bg={Nut.lime} />
              <span style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.1 }}>
                <span>{c.name}</span>
                <span style={{ fontSize: 10, fontWeight: 500, color: Nut.n500, marginTop: 1 }}>{c.role}</span>
              </span>
              <button style={{
                background: 'rgba(10,31,92,0.08)', border: 0, cursor: 'pointer',
                width: 20, height: 20, borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: Nut.navy, marginLeft: 2,
              }}>
                <Icon name="close" size={13} weight={700} />
              </button>
            </span>
          ))}
        </div>

        <Btn variant="secondary" icon="add" full size="md">
          Adicionar profissional
        </Btn>

        {/* Suggestions */}
        <div style={{
          fontSize: 11, fontWeight: 700, letterSpacing: '0.08em',
          textTransform: 'uppercase', color: Nut.n500,
          margin: '22px 0 10px',
        }}>Sugeridos nesta unidade</div>
        <div style={{
          background: '#fff', borderRadius: 14, overflow: 'hidden',
          boxShadow: '0 2px 8px rgba(10,31,92,0.05)',
        }}>
          {suggestions.map((s, i, arr) => (
            <div key={s.name} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '12px 14px',
              borderBottom: i < arr.length - 1 ? `1px solid ${Nut.n100}` : 'none',
            }}>
              <Avatar initials={s.name.split(' ').slice(-2).map(n => n[0]).join('')} size={34} bg={Nut.navy100} color={Nut.navy} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: Nut.navy }}>{s.name}</div>
                <div style={{ fontSize: 11.5, color: Nut.n500 }}>{s.role}</div>
              </div>
              <button style={{
                background: 'transparent', border: `1.5px solid ${Nut.lime}`,
                color: Nut.limeP, cursor: 'pointer',
                width: 32, height: 32, borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name="add" size={18} weight={700} />
              </button>
            </div>
          ))}
        </div>
      </div>
      <StepFooter />
    </div>
  );
}

// ─── Etapa 5 — Objetivos ─────────────────────────────────────
function Step5Objectives() {
  const items = [
    { k: 'Contagem de consignados',     on: true  },
    { k: 'Padronização',                 on: true  },
    { k: 'Apresentação de produto',      on: false },
    { k: 'Treinamento de equipe',        on: false },
    { k: 'Cotação / comercial',          on: false },
    { k: 'Reposição de estoque',         on: false },
    { k: 'Auditoria clínica',            on: false },
    { k: 'Outros',                       on: false },
  ];
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: Nut.n50, position: 'relative' }}>
      <StepperHeader current={5} total={7} />
      <div style={{ flex: 1, overflow: 'auto', padding: '20px 16px 120px' }}>
        <SectionLabel n={5} title="Objetivos da visita"
          subtitle="Marque todos que se aplicam (2 selecionados)." />

        <div style={{
          background: '#fff', borderRadius: 14, overflow: 'hidden',
          boxShadow: '0 2px 8px rgba(10,31,92,0.05)',
        }}>
          {items.map((it, i, arr) => (
            <label key={it.k} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '14px 14px',
              borderBottom: i < arr.length - 1 ? `1px solid ${Nut.n100}` : 'none',
              cursor: 'pointer',
              background: it.on ? Nut.lime50 : '#fff',
            }}>
              <div style={{
                width: 24, height: 24, borderRadius: 7,
                background: it.on ? Nut.lime : '#fff',
                border: `1.5px solid ${it.on ? Nut.lime : Nut.n300}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
                transition: 'all 120ms',
              }}>
                {it.on && <Icon name="check" size={16} color="#fff" weight={700} />}
              </div>
              <div style={{
                flex: 1,
                fontFamily: 'Inter, sans-serif',
                fontSize: 14.5,
                fontWeight: it.on ? 600 : 500,
                color: Nut.navy,
              }}>{it.k}</div>
              {it.on && (
                <span style={{
                  fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                  textTransform: 'uppercase', color: Nut.limeP,
                }}>marcado</span>
              )}
            </label>
          ))}
        </div>
      </div>
      <StepFooter />
    </div>
  );
}

Object.assign(window, { Step2Schedule, Step4Professionals, Step5Objectives });
