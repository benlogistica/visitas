/* eslint-disable */
// Tela 1 — Início (Home mobile)

function HomeScreen() {
  return (
    <div style={{
      height: '100%', width: '100%',
      display: 'flex', flexDirection: 'column',
      background: Nut.n50,
      overflow: 'hidden',
    }}>
      {/* Navy top bar: logo + avatar + bell */}
      <div style={{
        background: Nut.navy, color: '#fff',
        paddingTop: 50, paddingBottom: 14,
        paddingLeft: 20, paddingRight: 20,
        position: 'relative',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <img src={window.__resources && window.__resources.logoWhite} alt="Nutricionais"
            style={{ height: 24, flex: 1, objectFit: 'contain', objectPosition: 'left' }} />
          <button style={{
            background: 'rgba(255,255,255,0.08)', border: 0, cursor: 'pointer',
            width: 40, height: 40, borderRadius: '50%',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: '#fff', position: 'relative',
          }}>
            <Icon name="notifications" size={22} weight={500} />
            <span style={{
              position: 'absolute', top: 6, right: 6,
              width: 10, height: 10, borderRadius: '50%',
              background: Nut.lime, border: `2px solid ${Nut.navy}`,
            }} />
          </button>
          <Avatar initials="ED" size={40} bg={Nut.lime} />
        </div>
      </div>

      {/* Scroll area */}
      <div style={{
        flex: 1, overflow: 'auto',
        padding: '20px 20px 110px',
      }}>
        {/* Greeting */}
        <div style={{ marginBottom: 18 }}>
          <div style={{
            fontFamily: 'Poppins, sans-serif',
            fontSize: 24, fontWeight: 700,
            color: Nut.navy, letterSpacing: '-0.02em',
            lineHeight: 1.15,
          }}>
            Boa tarde, Dr. Eduardo
          </div>
          <div style={{
            marginTop: 4,
            fontSize: 13, color: Nut.n500,
            fontFamily: 'Inter, sans-serif', fontWeight: 500,
          }}>
            Sábado, 18 abr 2026
          </div>
        </div>

        {/* Next visit card */}
        <div style={{
          background: '#fff',
          border: `1px solid ${Nut.navy100}`,
          borderRadius: 14,
          padding: 16,
          marginBottom: 18,
          boxShadow: '0 4px 12px rgba(10,31,92,0.06)',
          position: 'relative',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
            <span style={{
              fontSize: 10, fontWeight: 700, letterSpacing: '0.08em',
              textTransform: 'uppercase', color: Nut.limeP,
              padding: '3px 8px', borderRadius: 4,
              background: Nut.lime50,
            }}>Próxima visita</span>
            <span style={{
              fontFamily: 'JetBrains Mono, monospace',
              fontSize: 11, fontWeight: 600, color: Nut.n500,
            }}>HOJE · 14:30</span>
          </div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <BrandCircle icon="local_hospital" size={44} bg={Nut.navy} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                fontFamily: 'Poppins, sans-serif',
                fontSize: 16, fontWeight: 600, color: Nut.navy,
                lineHeight: 1.25,
              }}>
                Hospital São Luiz Morumbi
              </div>
              <div style={{
                fontSize: 12.5, color: Nut.n600, marginTop: 4,
                display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap',
              }}>
                <Icon name="flag" size={14} color={Nut.n500} />
                <span>Objetivo: <b style={{ color: Nut.navy, fontWeight: 600 }}>Padronização</b></span>
              </div>
            </div>
          </div>
          <div style={{
            display: 'flex', justifyContent: 'flex-end',
            marginTop: 12,
            paddingTop: 12,
            borderTop: `1px solid ${Nut.n100}`,
          }}>
            <Btn variant="secondary" size="md" iconRight="arrow_forward">
              Ver detalhes
            </Btn>
          </div>
        </div>

        {/* GIANT check-in CTA */}
        <button style={{
          width: '100%',
          minHeight: 76,
          padding: '18px 24px',
          borderRadius: 9999,
          border: 0,
          background: `linear-gradient(180deg, ${Nut.lime} 0%, ${Nut.limeP} 100%)`,
          color: '#fff',
          boxShadow: '0 10px 28px rgba(139,198,63,0.45), inset 0 1.5px 0 rgba(255,255,255,0.35), inset 0 -1px 0 rgba(0,0,0,0.08)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14,
          cursor: 'pointer',
          marginBottom: 22,
          fontFamily: 'Poppins, sans-serif',
        }}>
          <span style={{
            width: 44, height: 44, borderRadius: '50%',
            background: 'rgba(255,255,255,0.2)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Icon name="my_location" size={26} color="#fff" weight={600} />
          </span>
          <span style={{
            fontSize: 20, fontWeight: 700, letterSpacing: '-0.01em',
          }}>Fazer check-in</span>
        </button>

        {/* KPI grid 2x2 */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10,
          marginBottom: 22,
        }}>
          {[
            { icon: 'check_circle', label: 'Visitas este mês', value: '18',   sub: '+4 vs. mar' },
            { icon: 'hourglass_top', label: 'Em revisão',       value: '2',    sub: 'ver fila' },
            { icon: 'business',      label: 'Instituições',     value: '14',    sub: 'ativas' },
            { icon: 'payments',      label: 'Faturamento mês',  value: 'R$ 842k', sub: '+12%' },
          ].map(k => (
            <div key={k.label} style={{
              background: '#fff',
              borderRadius: 14,
              padding: 14,
              boxShadow: '0 2px 8px rgba(10,31,92,0.05)',
              display: 'flex', flexDirection: 'column', gap: 10,
            }}>
              <BrandCircle icon={k.icon} size={36} bg={Nut.lime} />
              <div>
                <div style={{
                  fontFamily: 'Poppins, sans-serif',
                  fontSize: k.value.length > 5 ? 18 : 24, fontWeight: 700,
                  color: Nut.navy, lineHeight: 1, letterSpacing: '-0.02em',
                  fontVariantNumeric: 'tabular-nums',
                }}>{k.value}</div>
                <div style={{
                  fontSize: 11, color: Nut.n500, marginTop: 6,
                  fontWeight: 600,
                  letterSpacing: '0.02em',
                  lineHeight: 1.2,
                }}>{k.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Recent visits */}
        <div style={{
          display: 'flex', alignItems: 'baseline', justifyContent: 'space-between',
          marginBottom: 12,
        }}>
          <h2 style={{
            margin: 0,
            fontFamily: 'Poppins, sans-serif',
            fontSize: 16, fontWeight: 600, color: Nut.navy,
          }}>Visitas recentes</h2>
          <button style={{
            background: 'none', border: 0, cursor: 'pointer',
            color: Nut.limeP, fontFamily: 'Inter, sans-serif',
            fontSize: 13, fontWeight: 600,
          }}>Ver todas</button>
        </div>

        <div style={{
          background: '#fff', borderRadius: 14, overflow: 'hidden',
          boxShadow: '0 2px 8px rgba(10,31,92,0.05)',
        }}>
          {[
            { h: 'Hospital Albert Einstein', t: 'Ontem · 16:40', s: 'approved' },
            { h: 'Hosp. Sírio-Libanês',      t: 'Ontem · 11:05', s: 'review' },
            { h: 'Hospital Samaritano',      t: '16 abr · 09:20', s: 'approved' },
            { h: 'Hosp. 9 de Julho',         t: '15 abr · 14:20', s: 'pending' },
          ].map((v, i, arr) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '14px 16px',
              borderBottom: i < arr.length - 1 ? `1px solid ${Nut.n100}` : 'none',
            }}>
              <div style={{
                width: 38, height: 38, borderRadius: 10,
                background: Nut.navy50,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}>
                <Icon name="local_hospital" size={20} color={Nut.navy} weight={500} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{
                  fontFamily: 'Inter, sans-serif',
                  fontSize: 14, fontWeight: 600, color: Nut.navy,
                  lineHeight: 1.3,
                  overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                }}>{v.h}</div>
                <div style={{
                  fontSize: 11.5, color: Nut.n500, marginTop: 2,
                  fontFamily: 'JetBrains Mono, monospace',
                }}>{v.t}</div>
              </div>
              <StatusBadge status={v.s} />
            </div>
          ))}
        </div>
      </div>

      {/* Bottom tab bar — 5 items, check-in in the middle (raised) */}
      <BottomTabs active="checkin" />
    </div>
  );
}

function BottomTabs({ active }) {
  const items = [
    { id: 'home',     icon: 'home',            label: 'Início'      },
    { id: 'visits',   icon: 'list_alt',        label: 'Visitas'     },
    { id: 'checkin',  icon: 'my_location',     label: 'Check-in', primary: true },
    { id: 'agenda',   icon: 'calendar_month',  label: 'Agenda'      },
    { id: 'billing',  icon: 'payments',        label: 'Faturamento' },
  ];
  return (
    <div style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      background: '#fff',
      borderTop: `1px solid ${Nut.n200}`,
      paddingTop: 8,
      paddingBottom: 26,
      display: 'flex',
      justifyContent: 'space-around',
      alignItems: 'flex-end',
      zIndex: 40,
      boxShadow: '0 -4px 16px rgba(10,31,92,0.04)',
    }}>
      {items.map(it => {
        const isActive = it.id === active;
        if (it.primary) {
          return (
            <button key={it.id} style={{
              background: 'transparent', border: 0, cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              padding: 0, marginTop: -22,
            }}>
              <div style={{
                width: 52, height: 52, borderRadius: '50%',
                background: `linear-gradient(180deg, ${Nut.lime} 0%, ${Nut.limeP} 100%)`,
                boxShadow: '0 6px 16px rgba(139,198,63,0.45), inset 0 1px 0 rgba(255,255,255,0.3)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Icon name={it.icon} size={26} color="#fff" weight={600} />
              </div>
              <span style={{
                fontSize: 10.5, fontWeight: 700, color: Nut.limeP,
                fontFamily: 'Inter, sans-serif',
                letterSpacing: '-0.01em',
              }}>{it.label}</span>
            </button>
          );
        }
        return (
          <button key={it.id} style={{
            background: 'transparent', border: 0, cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            padding: '4px 6px',
            minWidth: 50,
          }}>
            <Icon name={it.icon} size={22}
              color={isActive ? Nut.navy : Nut.n500}
              weight={isActive ? 600 : 400}
              fill={isActive ? 1 : 0}
            />
            <span style={{
              fontSize: 10.5,
              fontWeight: isActive ? 700 : 500,
              color: isActive ? Nut.navy : Nut.n500,
              fontFamily: 'Inter, sans-serif',
              letterSpacing: '-0.01em',
            }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

Object.assign(window, { HomeScreen, BottomTabs });
