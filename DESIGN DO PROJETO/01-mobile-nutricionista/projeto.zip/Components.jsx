/* eslint-disable */
// Componentes base — Nutricionais CRM mobile
// Fundamentos: Poppins (display), Inter (body), JetBrains Mono (dados).
// Ícones: Material Symbols Rounded.

const Nut = {
  navy:      '#0A1F5C',
  navy800:   '#0E2872',
  navy100:   '#E3E7F1',
  navy50:    '#F3F5FA',
  lime:      '#8BC63F',
  limeH:     '#7AB033',
  limeP:     '#689628',
  lime100:   '#E7F3D4',
  lime50:    '#F4F9EA',
  success:   '#22A06B',
  success50: '#E6F6EF',
  warning:   '#F59E0B',
  warning50: '#FEF4E1',
  danger:    '#DC2626',
  danger50:  '#FCE8E8',
  info:      '#2563EB',
  info50:    '#E4ECFD',
  n0:   '#FFFFFF',
  n50:  '#FAFBFC',
  n100: '#F3F4F6',
  n200: '#E5E7EB',
  n300: '#D1D5DB',
  n400: '#9CA3AF',
  n500: '#6B7280',
  n600: '#4B5563',
  n700: '#374151',
  n800: '#1F2937',
  n900: '#111827',
};

function Icon({ name, size = 24, color, weight = 500, fill = 0, style = {} }) {
  return (
    <span className="material-symbols-rounded"
      style={{
        fontSize: size,
        color: color || 'currentColor',
        fontVariationSettings: `'FILL' ${fill}, 'wght' ${weight}, 'GRAD' 0, 'opsz' 24`,
        lineHeight: 1,
        display: 'inline-flex',
        userSelect: 'none',
        ...style,
      }}>{name}</span>
  );
}

// Pill button — primary (lime), secondary (outline navy), ghost, danger
function Btn({ children, variant = 'primary', icon, iconRight, onClick, disabled, full, size = 'md', style = {} }) {
  const h = size === 'xl' ? 64 : size === 'lg' ? 56 : 52;
  const fs = size === 'xl' ? 17 : 15;
  const variants = {
    primary: {
      background: disabled ? Nut.n300 : `linear-gradient(180deg, ${Nut.lime} 0%, ${Nut.limeH} 100%)`,
      color: '#fff',
      boxShadow: disabled ? 'none' : '0 6px 16px rgba(139,198,63,0.35), inset 0 1px 0 rgba(255,255,255,0.35)',
    },
    secondary: {
      background: '#fff',
      color: Nut.navy,
      border: `1.5px solid ${disabled ? Nut.n300 : Nut.navy}`,
    },
    ghost: {
      background: 'transparent',
      color: Nut.navy,
    },
    danger: {
      background: Nut.danger,
      color: '#fff',
      boxShadow: '0 6px 16px rgba(220,38,38,0.28)',
    },
    link: {
      background: 'transparent',
      color: Nut.navy,
      textDecoration: 'underline',
      textUnderlineOffset: 4,
    },
  };
  return (
    <button
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      style={{
        height: h,
        padding: '0 24px',
        borderRadius: 9999,
        border: 0,
        fontFamily: 'Inter, sans-serif',
        fontWeight: 600,
        fontSize: fs,
        letterSpacing: '-0.01em',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        cursor: disabled ? 'not-allowed' : 'pointer',
        width: full ? '100%' : undefined,
        transition: 'transform 120ms cubic-bezier(0.22,0.61,0.36,1), filter 160ms',
        outline: 'none',
        ...variants[variant],
        ...style,
      }}
      onMouseDown={(e) => !disabled && (e.currentTarget.style.transform = 'scale(0.98)')}
      onMouseUp={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
    >
      {icon && <Icon name={icon} size={size === 'xl' ? 24 : 20} weight={600} />}
      <span>{children}</span>
      {iconRight && <Icon name={iconRight} size={size === 'xl' ? 24 : 20} weight={600} />}
    </button>
  );
}

function StatusBadge({ status, label }) {
  const map = {
    approved:  { bg: Nut.success50, fg: '#15803d', dot: Nut.success, text: 'Aprovada' },
    pending:   { bg: Nut.warning50, fg: '#B45309', dot: Nut.warning, text: 'Divergência' },
    review:    { bg: Nut.info50,    fg: '#1D4ED8', dot: Nut.info,    text: 'Em revisão' },
    rejected:  { bg: Nut.danger50,  fg: '#B91C1C', dot: Nut.danger,  text: 'Rejeitada' },
    draft:     { bg: Nut.n100,      fg: Nut.n600,  dot: Nut.n400,    text: 'Rascunho' },
    inprogress:{ bg: Nut.lime50,    fg: Nut.limeP, dot: Nut.lime,    text: 'Em andamento' },
  };
  const s = map[status] || map.draft;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      height: 22, padding: '0 9px', borderRadius: 9999,
      background: s.bg, color: s.fg,
      fontSize: 11, fontWeight: 600, letterSpacing: '0.01em',
      fontFamily: 'Inter, sans-serif',
    }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: s.dot }} />
      {label || s.text}
    </span>
  );
}

// Circular green icon (brand signature) — 48px default
function BrandCircle({ icon, size = 48, bg = Nut.lime }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0,
    }}>
      <Icon name={icon} size={Math.round(size * 0.5)} color="#fff" weight={600} />
    </div>
  );
}

// Avatar with initials
function Avatar({ initials, size = 40, bg = Nut.lime, color = '#fff' }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: bg, color,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'Poppins, sans-serif', fontWeight: 700,
      fontSize: Math.round(size * 0.38),
      flexShrink: 0, letterSpacing: '-0.02em',
    }}>{initials}</div>
  );
}

// iOS status bar (14:32 · 100% · 5G)
function IOSStatus({ time = '14:32', dark = true }) {
  const c = dark ? '#fff' : '#000';
  return (
    <div style={{
      height: 44,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 28px',
      fontFamily: '-apple-system, "SF Pro", system-ui',
      fontWeight: 600, fontSize: 15,
      color: c,
      position: 'relative',
    }}>
      <span style={{ fontVariantNumeric: 'tabular-nums' }}>{time}</span>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: 0.2 }}>5G</span>
        {/* signal */}
        <svg width="18" height="11" viewBox="0 0 18 11" style={{ marginLeft: 2 }}>
          <rect x="0" y="7"   width="3" height="4"  rx="0.6" fill={c}/>
          <rect x="5" y="5"   width="3" height="6"  rx="0.6" fill={c}/>
          <rect x="10" y="2.5" width="3" height="8.5" rx="0.6" fill={c}/>
          <rect x="15" y="0"  width="3" height="11" rx="0.6" fill={c}/>
        </svg>
        {/* battery full */}
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x="0.5" y="0.5" width="22" height="11" rx="3" stroke={c} strokeOpacity="0.45" fill="none"/>
          <rect x="2" y="2" width="19" height="8" rx="1.8" fill={c}/>
          <rect x="24" y="4" width="1.5" height="4" rx="0.6" fill={c} fillOpacity="0.45"/>
        </svg>
      </div>
    </div>
  );
}

// iPhone 14 Pro-ish device shell — 390x844 viewport
function PhoneFrame({ children, statusDark = true, statusTime = '14:32', scale = 1 }) {
  return (
    <div style={{
      width: 390 * scale,
      height: 844 * scale,
      transformOrigin: 'top left',
    }}>
      <div style={{
        width: 390, height: 844,
        borderRadius: 52,
        background: '#0B0B0F',
        padding: 11,
        boxShadow: '0 40px 80px -20px rgba(10,31,92,0.25), 0 0 0 1px rgba(0,0,0,0.9), 0 0 0 2px rgba(255,255,255,0.08), 0 0 0 3px rgba(0,0,0,0.6)',
        position: 'relative',
        transform: `scale(${scale})`,
        transformOrigin: 'top left',
      }}>
        <div style={{
          width: '100%', height: '100%',
          borderRadius: 42,
          overflow: 'hidden',
          background: Nut.n50,
          position: 'relative',
        }}>
          {/* Dynamic island */}
          <div style={{
            position: 'absolute', top: 11, left: '50%', transform: 'translateX(-50%)',
            width: 124, height: 36, borderRadius: 22, background: '#000',
            zIndex: 100,
          }} />
          {/* Status bar */}
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, zIndex: 50 }}>
            <IOSStatus time={statusTime} dark={statusDark} />
          </div>
          {/* Content */}
          <div style={{ width: '100%', height: '100%', position: 'relative' }}>
            {children}
          </div>
          {/* Home indicator */}
          <div style={{
            position: 'absolute', bottom: 8, left: '50%', transform: 'translateX(-50%)',
            width: 134, height: 5, borderRadius: 100,
            background: statusDark ? 'rgba(255,255,255,0.9)' : 'rgba(0,0,0,0.3)',
            zIndex: 120,
          }} />
        </div>
      </div>
    </div>
  );
}

// Top bar for inner screens (navy background)
function NavyTopBar({ title, onBack, right, liveIndicator, children, logo }) {
  return (
    <div style={{
      background: Nut.navy,
      color: '#fff',
      paddingTop: 44, // status bar space
      paddingBottom: 14,
      paddingLeft: 16, paddingRight: 16,
      position: 'relative',
      zIndex: 5,
    }}>
      {children ? children : (
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, minHeight: 40 }}>
          {onBack && (
            <button onClick={onBack} style={{
              background: 'rgba(255,255,255,0.08)',
              border: 0, color: '#fff', cursor: 'pointer',
              width: 36, height: 36, borderRadius: '50%',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Icon name="arrow_back_ios_new" size={18} weight={600} />
            </button>
          )}
          {logo && (
            <img src="assets/nutri-logo-white.png" alt="Nutricionais"
              style={{ height: 22, marginRight: 4 }} />
          )}
          {liveIndicator && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '4px 10px', borderRadius: 9999,
              background: 'rgba(139,198,63,0.18)',
              border: '1px solid rgba(139,198,63,0.4)',
              fontSize: 11, fontWeight: 700, letterSpacing: '0.06em',
              textTransform: 'uppercase', color: '#C8E68C',
            }}>
              <span className="pulse-dot" style={{
                width: 8, height: 8, borderRadius: '50%', background: Nut.lime,
                boxShadow: `0 0 0 0 ${Nut.lime}`,
              }} />
              Em visita
            </span>
          )}
          <div style={{
            flex: 1,
            fontFamily: 'Poppins, sans-serif',
            fontSize: 17, fontWeight: 600, letterSpacing: '-0.01em',
          }}>{title}</div>
          {right}
        </div>
      )}
    </div>
  );
}

// Generic card
function Card({ children, style = {}, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: '#fff',
      borderRadius: 14,
      boxShadow: '0 4px 12px rgba(10,31,92,0.06), 0 1px 2px rgba(10,31,92,0.04)',
      padding: 16,
      cursor: onClick ? 'pointer' : 'default',
      ...style,
    }}>{children}</div>
  );
}

Object.assign(window, {
  Nut, Icon, Btn, StatusBadge, BrandCircle, Avatar,
  IOSStatus, PhoneFrame, NavyTopBar, Card,
});
